import streamlit as st


def render_alerts():

    st.markdown(
        """
        <div class="section-title">
        Schedule Alerts
        </div>
        """,
        unsafe_allow_html=True
    )

    st.info(
        "Calendar conflict detection will appear here."
    )