import streamlit as st

def render_priorities(
    tasks,
    theme
):

    st.markdown(
        """
        <div class="section-title">
        Top Priorities
        </div>
        """,
        unsafe_allow_html=True
    )

    if len(tasks) == 0:

        st.info("No tasks available.")

        return

    for task in tasks:

        score = task[4] * task[5]

        st.markdown(
            f"""
            <div class="card">

                <div style="
                display:flex;
                justify-content:space-between;
                align-items:center;
                ">

                    <h4 style="
                    margin:0;
                    ">
                        {task[1]}
                    </h4>

                    <span style="
                    color:{theme['accent1']};
                    font-size:1.2rem;
                    font-weight:700;
                    ">
                        {score}
                    </span>

                </div>

                <div style="
                display:flex;
                justify-content:space-between;
                margin-top:10px;
                opacity:0.8;
                ">

                    <span>
                        {task[2]}
                    </span>

                    <span>
                        {task[3]}
                    </span>

                </div>

            </div>

            <br>
            """,
            unsafe_allow_html=True
        )