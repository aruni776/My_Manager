import streamlit as st


def render_sidebar(themes):

    st.sidebar.markdown(
        """
        <div style="
        padding-bottom:15px;
        ">

            <h2 style="
            margin-bottom:0;
            ">
            Student OS
            </h2>

            <p style="
            opacity:0.7;
            margin-top:4px;
            ">
            Academic Command Center
            </p>

        </div>
        """,
        unsafe_allow_html=True
    )

    st.sidebar.divider()

    selected_theme = st.sidebar.selectbox(
        "Theme",
        list(themes.keys())
    )

    return selected_theme