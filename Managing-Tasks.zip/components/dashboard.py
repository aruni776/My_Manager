import streamlit as st


def render_dashboard_cards(
    total_tasks,
    event_count,
    productivity
):

    col1, col2, col3 = st.columns(3)

    with col1:

        st.markdown(
            f"""
            <div class="card">

                <div style="
                font-size:0.9rem;
                opacity:0.7;
                ">
                    Total Tasks
                </div>

                <div style="
                font-size:2.5rem;
                font-weight:700;
                margin-top:8px;
                ">
                    {total_tasks}
                </div>

                <div style="
                opacity:0.6;
                margin-top:6px;
                ">
                    Active commitments
                </div>

            </div>
            """,
            unsafe_allow_html=True
        )

    with col2:

        st.markdown(
            f"""
            <div class="card">

                <div style="
                font-size:0.9rem;
                opacity:0.7;
                ">
                    Upcoming Events
                </div>

                <div style="
                font-size:2.5rem;
                font-weight:700;
                margin-top:8px;
                ">
                    {event_count}
                </div>

                <div style="
                opacity:0.6;
                margin-top:6px;
                ">
                    Scheduled activities
                </div>

            </div>
            """,
            unsafe_allow_html=True
        )

    with col3:

        st.markdown(
            f"""
            <div class="card">

                <div style="
                font-size:0.9rem;
                opacity:0.7;
                ">
                    Productivity
                </div>

                <div style="
                font-size:2.5rem;
                font-weight:700;
                margin-top:8px;
                ">
                    {productivity:.0f}%
                </div>

                <div style="
                opacity:0.6;
                margin-top:6px;
                ">
                    Completion rate
                </div>

            </div>
            """,
            unsafe_allow_html=True
        )