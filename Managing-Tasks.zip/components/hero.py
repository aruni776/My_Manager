import streamlit as st

def render_hero():

    st.markdown(
        """
        # Welcome Back, JC

        Manage academics, events, deadlines and personal goals from a single dashboard.
        """
    )

    st.markdown("<br>", unsafe_allow_html=True)