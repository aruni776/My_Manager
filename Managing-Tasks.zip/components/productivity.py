import streamlit as st

def render_productivity(
    productivity,
    completed_tasks
):

    st.markdown(
        """
        <div class="section-title">
        Productivity Overview
        </div>
        """,
        unsafe_allow_html=True
    )

    c1, c2 = st.columns(2)

    with c1:

        st.markdown(
            f"""
            <div class="card">

                <h4>Completion Rate</h4>

                <h2>{productivity:.1f}%</h2>

            </div>
            """,
            unsafe_allow_html=True
        )

    with c2:

        st.markdown(
            f"""
            <div class="card">

                <h4>Completed Tasks</h4>

                <h2>{completed_tasks}</h2>

            </div>
            """,
            unsafe_allow_html=True
        )