import streamlit as st

def render_life_areas(rows):

    st.markdown(
        """
        <div class="section-title">
        Life Areas
        </div>
        """,
        unsafe_allow_html=True
    )

    for row in rows:

        st.markdown(
            f"""
            <div class="card">

                <h4>{row[0]}</h4>

                <h2>{row[1]}</h2>

            </div>

            <br>
            """,
            unsafe_allow_html=True
        )