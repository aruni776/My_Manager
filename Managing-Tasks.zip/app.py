import streamlit as st

from assets.themes import THEMES
from assets.theme import apply_theme

from components.sidebar import render_sidebar
from components.hero import render_hero
from components.dashboard import render_dashboard_cards
from components.priorities import render_priorities
from components.life_areas import render_life_areas
from components.productivity import render_productivity
from components.alerts import render_alerts

from database.dashboard_queries import (
    load_dashboard_data
)

# =====================================================
# PAGE CONFIG
# =====================================================

st.set_page_config(
    page_title="Student OS",
    page_icon="🎓",
    layout="wide"
)

# =====================================================
# SIDEBAR
# =====================================================

selected_theme = render_sidebar(
    THEMES
)

theme = THEMES[selected_theme]

# =====================================================
# THEME
# =====================================================

st.markdown(
    apply_theme(theme),
    unsafe_allow_html=True
)

# =====================================================
# DASHBOARD DATA
# =====================================================

data = load_dashboard_data()

# =====================================================
# HERO
# =====================================================

render_hero()

# =====================================================
# KPI CARDS
# =====================================================

render_dashboard_cards(
    data["total_tasks"],
    data["event_count"],
    data["productivity"]
)

st.markdown("<br>", unsafe_allow_html=True)

# =====================================================
# MAIN GRID
# =====================================================

left_col, right_col = st.columns([2, 1])

with left_col:

    render_priorities(
        data["top_tasks"],
        theme
    )

with right_col:

    render_life_areas(
        data["category_rows"]
    )

# =====================================================
# PRODUCTIVITY
# =====================================================

render_productivity(
    data["productivity"],
    data["completed_tasks"]
)

# =====================================================
# ALERTS
# =====================================================

render_alerts()