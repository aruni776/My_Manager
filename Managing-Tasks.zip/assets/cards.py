def card_styles(theme):

    return f"""

    .card {{

        background:
        linear-gradient(
            145deg,
            rgba(20,28,45,0.92),
            rgba(10,15,30,0.85)
        );

        border:
        1px solid rgba(255,255,255,0.06);

        border-radius: 20px;

        padding: 18px;

        backdrop-filter: blur(18px);

        box-shadow:
        0 0 30px rgba(0,0,0,0.35),
        0 0 12px {theme['accent1']}15;

        transition: all 0.3s ease;
    }}

    .card:hover {{

        transform: translateY(-2px);

        box-shadow:
        0 0 35px {theme['accent1']}20;
    }}
    """