def layout_styles():

    return """

    .block-container {

        padding-top: 2rem;
        padding-left: 3rem;
        padding-right: 3rem;
    }
    """