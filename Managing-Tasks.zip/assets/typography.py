def typography_styles(theme):

    return f"""

    h1 {{

        font-size: 3rem;
        font-weight: 700;

        background:
        linear-gradient(
            90deg,
            white,
            {theme['accent1']}
        );

        -webkit-background-clip:text;
        -webkit-text-fill-color:transparent;
    }}

    .section-title {{

        font-size:1.6rem;
        font-weight:600;

        margin-bottom:1rem;
    }}
    """