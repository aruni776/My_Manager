def apply_theme(theme):

    return """
    <style>

    .stApp{
        background:#050816;
        color:white;
    }

    </style>
    """