THEMES = {

    "Aurora": {

        "bg": "#050816",

        "text": "#FFFFFF",

        "accent1": "#3B82F6",

        "accent2": "#8B5CF6"
    },

    "Emerald": {

        "bg": "#050816",

        "text": "#FFFFFF",

        "accent1": "#10B981",

        "accent2": "#34D399"
    },

    "Sunset": {

        "bg": "#050816",

        "text": "#FFFFFF",

        "accent1": "#F97316",

        "accent2": "#FB7185"
    },

    "Crimson": {

        "bg": "#050816",

        "text": "#FFFFFF",

        "accent1": "#EF4444",

        "accent2": "#F43F5E"
    }
}