def sidebar_styles():

    return """

    section[data-testid="stSidebar"] {

        background:
        linear-gradient(
            180deg,
            rgba(8,12,25,0.98),
            rgba(5,8,18,0.98)
        );

        border-right:
        1px solid rgba(255,255,255,0.06);

        backdrop-filter: blur(20px);
    }

    section[data-testid="stSidebar"] h2 {

        font-weight: 700;
        letter-spacing: 0.5px;
    }

    section[data-testid="stSidebar"] hr {

        border-color:
        rgba(255,255,255,0.08);
    }

    /* Page navigation */

    div[data-testid="stSidebarNav"] {

        padding-top: 1rem;
    }

    div[data-testid="stSidebarNav"] ul {

        gap: 8px;
    }

    div[data-testid="stSidebarNav"] a {

        border-radius: 14px;

        padding: 10px 12px;

        background:
        rgba(255,255,255,0.02);

        transition: all 0.2s ease;
    }

    div[data-testid="stSidebarNav"] a:hover {

        background:
        rgba(255,255,255,0.05);

        transform: translateX(3px);
    }

    div[data-testid="stSidebarNav"] a[aria-current="page"] {

        background:
        rgba(59,130,246,0.15);

        border:
        1px solid rgba(59,130,246,0.25);

        box-shadow:
        0 0 15px rgba(59,130,246,0.15);
    }

    """